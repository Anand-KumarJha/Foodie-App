package model

data class FoodMenu(
    var itemId: String,
    var restaurantId: String,
    var restaurantName: String,
    var itemName: String,
    var itemPrice: String
)